####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

 

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

 

#2. Create Durable 
#################################################################################################
curl -i -X POST  -H "Content-Type:application/json"  http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores/store_ri/durables -d '{"name":"dur_pofutureinventory_async_v1","description":"Persistence durable creation for BS_POFutureInventory","type":"shared","ack_settings":{"mode":"sync"},"message_ttl":"0","interest":{"type":"matcher","value":{"ServiceName":"BS_190_POFutureInventory"}}}'
#################################################################################################

 

#3. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"dur_pofutureinventory_async_v1 deployment","description":"This deployment creates a Persistent durable for BS_POFutureInventory"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################