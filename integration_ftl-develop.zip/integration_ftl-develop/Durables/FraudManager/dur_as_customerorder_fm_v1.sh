####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Durable 
#################################################################################################
curl -i -X POST  -H "Content-Type:application/json"  http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores/store_fm/durables -d '{"name":"dur_as_customerorder_fm_v1","description":"Persistence durable creation for AS_customerorder_fm","type":"shared","ack_settings":{"mode":"sync"},"message_ttl":"0","interest":{"type":"matcher","value":{"ServiceName":"AS_FM_004_01_NotifyCustomerOrderStatus"}}}'
#################################################################################################

#3. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"dur_as_customerorder_fm_v1 deployment","description":"This deployment creates a Persistent durable for AS_customerorder_fm"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################
