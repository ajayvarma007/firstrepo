####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Transport for Applications (Default transport type will be DTCP)
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_niam_send", "description":"SendTransport for NIAM Interfaces","transport_type":"dtcp","virtual_name":"group_niam"}' http://@FTL_URL@/api/v1/realm/transports
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_niam_receive","description":"ReceiveTransport for NIAM Interfaces","transport_type":"dtcp","virtual_name":"group_niam"}' http://@FTL_URL@/api/v1/realm/transports
#################################################################################################

#3. Create TransportGroup - groups the transports created in above step.
#################################################################################################
curl -i -X PUT  "Content-Type:application/json" -d '{"name":"group_niam", "transports":["transport_niam_send","transport_niam_receive"]}' http://@FTL_URL@/ftlui/api/v1/transportGroups/group_niam
#################################################################################################

#4. Create Persistence store - collects a stream of messages.
#################################################################################################
curl -i -X  POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores -d '{"name":"store_niam","description":"Persistence Store for NIAM Interfaces"}'
#################################################################################################

#5. Create Applications for Send and Receive (Use transport name created earlier)
#################################################################################################
curl -i -X  POST -H "Content-Type: application/json" -d '{ "name": "app_niam", "description":"Application for NIAM Interfaces", "store": "store_niam", "cluster": "cluster_rebusIntegration","preload_format_names": ["format_rebusIntegration"],"endpoints": [{ "name": "ep_niam_send","description":"Send EP for NIAM Interfaces", "store": "store_niam","cluster": "cluster_rebusIntegration","transports":[{ "name":"transport_niam_send", "receive": false,"receive_inbox": false,"send": true,"send_inbox": true }]},{ "name": "ep_niam_receive","description":"Receive EP for NIAM Interfaces", "store": "store_niam","cluster": "cluster_rebusIntegration","transports": [{"name": "transport_niam_receive","receive": true,"receive_inbox": true,"send": false,"send_inbox": false }] }]}' http://@FTL_URL@/api/v1/realm/applications
#################################################################################################

#6. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"FTL_GroupScript_NIAM deployment_V1","description":"This deployment creates Application, EndPoints, Transports and Store for NIAM Interfaces"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################
