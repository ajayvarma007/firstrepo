####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Transport for Applications (Default transport type will be DTCP)
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_mcd_send", "description":"SendTransport for mcd Interfaces","transport_type":"dtcp","virtual_name":"group_mcd"}' http://@FTL_URL@/api/v1/realm/transports
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_mcd_receive","description":"ReceiveTransport for mcd Interfaces","transport_type":"dtcp","virtual_name":"group_mcd"}' http://@FTL_URL@/api/v1/realm/transports
#################################################################################################

#3. Create TransportGroup - groups the transports created in above step.
#################################################################################################
curl -i -X PUT  "Content-Type:application/json" -d '{"name":"group_mcd", "transports":["transport_mcd_send","transport_mcd_receive"]}' http://@FTL_URL@/ftlui/api/v1/transportGroups/group_mcd
#################################################################################################

#4. Create Persistence store - collects a stream of messages.
#################################################################################################
curl -i -X  POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores -d '{"name":"store_mcd","description":"Persistence Store for mcd Interfaces"}'
#################################################################################################

#5. Create Applications for Send and Receive (Use transport name created earlier)
#################################################################################################
curl -i -X  POST -H "Content-Type: application/json" -d '{ "name": "app_mcd", "description":"Application for mcd Interfaces", "store": "store_mcd", "cluster": "cluster_rebusIntegration","preload_format_names": ["format_rebusIntegration"],"endpoints": [{ "name": "ep_mcd_send","description":"Send EP for mcd Interfaces", "store": "store_mcd","cluster": "cluster_rebusIntegration","transports":[{ "name":"transport_mcd_send", "receive": false,"receive_inbox": false,"send": true,"send_inbox": true }]},{ "name": "ep_mcd_receive","description":"Receive EP for Insights Interfaces", "store": "store_mcd","cluster": "cluster_rebusIntegration","transports": [{"name": "transport_mcd_receive","receive": true,"receive_inbox": true,"send": false,"send_inbox": false }] }]}' http://@FTL_URL@/api/v1/realm/applications
#################################################################################################

#6. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"FTL_GroupScript_Insights deployment_V1","description":"This deployment creates Application, EndPoints, Transports and Store for Insights Interfaces"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################
