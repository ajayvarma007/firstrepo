####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Transport for Applications (Default transport type will be DTCP)
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_rnp_send", "description":"SendTransport for RebusMNP Interfaces","transport_type":"dtcp","virtual_name":"group_rnp"}' http://@FTL_URL@/api/v1/realm/transports
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_rnp_receive","description":"ReceiveTransport for RebusMNP Interfaces","transport_type":"dtcp","virtual_name":"group_rnp"}' http://@FTL_URL@/api/v1/realm/transports
#################################################################################################

#3. Create TransportGroup - groups the transports created in above step.
#################################################################################################
curl -i -X PUT  "Content-Type:application/json" -d '{"name":"group_rnp", "transports":["transport_rnp_send","transport_rnp_receive"]}' http://@FTL_URL@/ftlui/api/v1/transportGroups/group_rnp
#################################################################################################

#4. Create Persistence store - collects a stream of messages.
#################################################################################################
curl -i -X  POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores -d '{"name":"store_rnp","description":"Persistence Store for RebusMNP Interfaces"}'
#################################################################################################

#5. Create Applications for Send and Receive (Use transport name created earlier)
#################################################################################################
curl -i -X  POST -H "Content-Type: application/json" -d '{ "name": "app_rnp", "description":"Application for RebusMNP Interfaces", "store": "store_rnp", "cluster": "cluster_rebusIntegration","preload_format_names": ["format_rebusIntegration"],"endpoints": [{ "name": "ep_rnp_send","description":"Send EP for RebusMNP Interfaces", "store": "store_rnp","cluster": "cluster_rebusIntegration","transports":[{ "name":"transport_rnp_send", "receive": false,"receive_inbox": false,"send": true,"send_inbox": true }]},{ "name": "ep_rnp_receive","description":"Receive EP for RebusMNP Interfaces", "store": "store_rnp","cluster": "cluster_rebusIntegration","transports": [{"name": "transport_rnp_receive","receive": true,"receive_inbox": true,"send": false,"send_inbox": false }] }]}' http://@FTL_URL@/api/v1/realm/applications
#################################################################################################

#6. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"FTL_GroupScript_RebusMNP deployment_V1","description":"This deployment creates Application, EndPoints, Transports and Store for RebusMNP Interfaces"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################
