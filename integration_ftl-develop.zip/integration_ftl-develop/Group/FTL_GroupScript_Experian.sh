####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Transport for Applications (Default transport type will be DTCP)
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_ex_send", "description":"SendTransport for Experian Interfaces","transport_type":"dtcp","virtual_name":"group_ex"}' http://@FTL_URL@/api/v1/realm/transports
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_ex_receive","description":"ReceiveTransport for Experian Interfaces","transport_type":"dtcp","virtual_name":"group_ex"}' http://@FTL_URL@/api/v1/realm/transports
#################################################################################################

#3. Create TransportGroup - groups the transports created in above step.
#################################################################################################
curl -i -X PUT  "Content-Type:application/json" -d '{"name":"group_ex", "transports":["transport_ex_send","transport_ex_receive"]}' http://@FTL_URL@/ftlui/api/v1/transportGroups/group_ex
#################################################################################################

#4. Create Persistence store - collects a stream of messages.
#################################################################################################
curl -i -X  POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores -d '{"name":"store_ex","description":"Persistence Store for Experian Interfaces"}'
#################################################################################################

#5. Create Applications for Send and Receive (Use transport name created earlier)
#################################################################################################
curl -i -X  POST -H "Content-Type: application/json" -d '{ "name": "app_ex", "description":"Application for Experian Interfaces", "store": "store_ex", "cluster": "cluster_rebusIntegration","preload_format_names": ["format_rebusIntegration"],"endpoints": [{ "name": "ep_ex_send","description":"Send EP for Experian Interfaces", "store": "store_ex","cluster": "cluster_rebusIntegration","transports":[{ "name":"transport_ex_send", "receive": false,"receive_inbox": false,"send": true,"send_inbox": true }]},{ "name": "ep_ex_receive","description":"Receive EP for Experian Interfaces", "store": "store_ex","cluster": "cluster_rebusIntegration","transports": [{"name": "transport_ex_receive","receive": true,"receive_inbox": true,"send": false,"send_inbox": false }] }]}' http://@FTL_URL@/api/v1/realm/applications
#################################################################################################

#6. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"FTL_GroupScript_Experian deployment_V1","description":"This deployment creates Application, EndPoints, Transports and Store for Experian Interfaces"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################
