####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Transport for Applications (Default transport type will be DTCP)
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_leg_send", "description":"SendTransport for LEG Interfaces","transport_type":"dtcp","virtual_name":"group_leg"}' http://@FTL_URL@/api/v1/realm/transports
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_leg_receive","description":"ReceiveTransport for LEG Interfaces","transport_type":"dtcp","virtual_name":"group_leg"}' http://@FTL_URL@/api/v1/realm/transports
#################################################################################################

#3. Create TransportGroup - groups the transports created in above step.
#################################################################################################
curl -i -X PUT  "Content-Type:application/json" -d '{"name":"group_leg", "transports":["transport_leg_send","transport_leg_receive"]}' http://@FTL_URL@/ftlui/api/v1/transportGroups/group_leg
#################################################################################################

#4. Create Persistence store - collects a stream of messages.
#################################################################################################
curl -i -X  POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores -d '{"name":"store_leg","description":"Persistence Store for LEG Interfaces"}'
#################################################################################################

#5. Create Applications for Send and Receive (Use transport name created earlier)
#################################################################################################
curl -i -X  POST -H "Content-Type: application/json" -d '{ "name": "app_leg", "description":"Application for LEG Interfaces", "store": "store_leg", "cluster": "cluster_rebusIntegration","preload_format_names": ["format_rebusIntegration"],"endpoints": [{ "name": "ep_leg_send","description":"Send EP for LEG Interfaces", "store": "store_leg","cluster": "cluster_rebusIntegration","transports":[{ "name":"transport_leg_send", "receive": false,"receive_inbox": false,"send": true,"send_inbox": true }]},{ "name": "ep_leg_receive","description":"Receive EP for LEG Interfaces", "store": "store_leg","cluster": "cluster_rebusIntegration","transports": [{"name": "transport_leg_receive","receive": true,"receive_inbox": true,"send": false,"send_inbox": false }] }]}' http://@FTL_URL@/api/v1/realm/applications
#################################################################################################

#6. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"FTL_GroupScript_LEG deployment_V1","description":"This deployment creates Application, EndPoints, Transports and Store for LEG Interfaces"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################