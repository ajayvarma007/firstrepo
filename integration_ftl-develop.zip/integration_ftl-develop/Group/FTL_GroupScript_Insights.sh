####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Transport for Applications (Default transport type will be DTCP)
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_dw_send", "description":"SendTransport for Insights Interfaces","transport_type":"dtcp","virtual_name":"group_dw"}' http://@FTL_URL@/api/v1/realm/transports
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"transport_dw_receive","description":"ReceiveTransport for Insights Interfaces","transport_type":"dtcp","virtual_name":"group_dw"}' http://@FTL_URL@/api/v1/realm/transports
#################################################################################################

#3. Create TransportGroup - groups the transports created in above step.
#################################################################################################
curl -i -X PUT  "Content-Type:application/json" -d '{"name":"group_dw", "transports":["transport_dw_send","transport_dw_receive"]}' http://@FTL_URL@/ftlui/api/v1/transportGroups/group_dw
#################################################################################################

#4. Create Persistence store - collects a stream of messages.
#################################################################################################
curl -i -X  POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/stores -d '{"name":"store_dw","description":"Persistence Store for Insights Interfaces"}'
#################################################################################################

#5. Create Applications for Send and Receive (Use transport name created earlier)
#################################################################################################
curl -i -X  POST -H "Content-Type: application/json" -d '{ "name": "app_dw", "description":"Application for Insights Interfaces", "store": "store_dw", "cluster": "cluster_rebusIntegration","preload_format_names": ["format_rebusIntegration"],"endpoints": [{ "name": "ep_dw_send","description":"Send EP for Insights Interfaces", "store": "store_dw","cluster": "cluster_rebusIntegration","transports":[{ "name":"transport_dw_send", "receive": false,"receive_inbox": false,"send": true,"send_inbox": true }]},{ "name": "ep_dw_receive","description":"Receive EP for Insights Interfaces", "store": "store_dw","cluster": "cluster_rebusIntegration","transports": [{"name": "transport_dw_receive","receive": true,"receive_inbox": true,"send": false,"send_inbox": false }] }]}' http://@FTL_URL@/api/v1/realm/applications
#################################################################################################

#6. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"FTL_GroupScript_Insights deployment_V1","description":"This deployment creates Application, EndPoints, Transports and Store for Insights Interfaces"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################
