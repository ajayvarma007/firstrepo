import os
import time
os.system("source /etc/profile")
path='/tmp/FTLAutomationScripts/' 
DirList=["Master","Group","Durables","ServerStart"]
for i in DirList:
        if(i=="Master"):
                os.system("chmod a+x "+path+i+"/"+"*")
                os.chdir(path+i)
                a=os.listdir(path+i)
                for j in a:
                        os.system(path+i+"/"+j)
        print ("*************************Master script executed******************************")
        if(i=="Group"):
              os.system("chmod a+x "+path+i+"/"+"*")
              os.chdir(path+i)
              a=os.listdir(path+i)
              for j in a:
                        os.system(path+i+"/"+j)
                        time.sleep(5)
        print ("**************************Group script executed**********************************")
        if(i=="Durables"):
               os.chdir(path+i)
               a=os.listdir(path+i)
               for j in a:
                    os.system("chmod a+x "+path+i+"/"+j+"/"+"*")
                    b=os.listdir(path+i+"/"+j)
                    for c in b:
                      os.system(path+i+"/"+j+"/"+c)
		      time.sleep(1)
        print ("******************************************Durables script executed*******************************")
	if(i=="ServerStart"):
                os.system("chmod a+x "+path+i+"/"+"*")
                os.chdir(path+i)
                a=os.listdir(path+i)
                for j in a:
                        os.system(path+i+"/"+j)
