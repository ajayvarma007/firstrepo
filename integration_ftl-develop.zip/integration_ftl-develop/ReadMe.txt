This is the Version_1 of FTL Automation scripts.

****Order of execution of the scripts will be as follows*****

	1)Master
	2)Group
	3)Durables
	4)ServerStart

*************************************************************