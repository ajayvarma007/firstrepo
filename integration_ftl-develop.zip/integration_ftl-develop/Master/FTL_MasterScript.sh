####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Create Workspace to edit the Realm Definition and lock so that no user can edit further
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/workspace
#################################################################################################

#2. Create Persistence Cluster
#################################################################################################
curl -i -X POST -H "Content-Type:application/json"  http://@FTL_URL@/api/v1/realm/persistence -d'{"name":"cluster_rebusIntegration","description":"Persistence Cluster for RebusIntegration and is shared across all interfaces"}'
#################################################################################################

#3. Create Persistence Server
#################################################################################################
curl -i -X POST  -H "Content-Type:application/json" http://@FTL_URL@/api/v1/realm/persistence/cluster_rebusIntegration/servers -d '{"name":"server_rebusIntegration","description":"Persistence Server for RebusIntegration and is shared across all interfaces"}'
#################################################################################################

#4. Create Message Format
#################################################################################################
curl -X POST http://@FTL_URL@/api/v1/realm/formats -d '{"name":"format_rebusIntegration","fields":[{"name":"Payload","type":"String"},{"name":"ServiceName","type":"String"}]}'
#################################################################################################

#5. Create Deployment 
#################################################################################################
curl -i -X POST -H "Content-Type:application/json" -d '{"name":"FTL_MasterScript deployment_V1","description":"This deployment creates a Persistent server, cluster and a message Format"}' http://@FTL_URL@/api/v1/realm/deployments
#################################################################################################
