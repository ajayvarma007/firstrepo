####FTL AUTOMATION SCRIPTS USING CURL COMMANDS####

#1. Start the Persistent Server post execution of all other scripts
#################################################################################################
@FTL_HOME@/bin/tibstore -d @FTL_HOME@/Store -rs http://@FTL_URL@ --name server_rebusIntegration &
#################################################################################################

sleep 5
 if (( $(ps -ef | grep -v grep | grep server_rebusIntegration | wc -l) > 0 ))
                then
                exit
        fi